import type { IncidentReport } from "../engines/generateIncidentReport";
import type { AIRemediationPlan } from "./aiRemediationPlanner";
import {
  executeRemediationPlan,
  type RemediationExecutionReport,
} from "./remediationExecutor";
import type { RemediationExecutionMode } from "./remediationTypes";

export type AgenticRemediationState =
  | "DETECTED"
  | "DIAGNOSED"
  | "PLANNED"
  | "POLICY_BLOCKED"
  | "AWAITING_APPROVAL"
  | "EXECUTING"
  | "VERIFYING"
  | "RESOLVED"
  | "FAILED";

export interface AgenticRemediationOptions {
  mode?: RemediationExecutionMode;
  maxActions?: number;
  approvalIds?: string[];
  verify?: boolean;
}

export interface AgenticRemediationStep {
  state: AgenticRemediationState;
  timestamp: string;
  message: string;
  actionId?: string;
}

export interface AgenticRemediationResult {
  incidentGeneratedAt: string;
  state: AgenticRemediationState;
  resolved: boolean;
  stopped: boolean;
  incidentScore: number;
  incidentLevel: string;
  plan: AIRemediationPlan | null;
  execution?: RemediationExecutionReport;
  steps: AgenticRemediationStep[];
  attemptedActions: number;
  maxActions: number;
  reason: string;
  startedAt: string;
  completedAt: string;
}

function getIncidentScore(report: IncidentReport): number {
  return Number(report.summary?.score ?? 0);
}

function getIncidentLevel(report: IncidentReport): string {
  return String(report.summary?.level ?? "Unknown");
}

function hasActiveIncident(report: IncidentReport): boolean {
  if (report.health?.healthy === false) {
    return true;
  }
  const findings = Array.isArray(report.health?.detailedFindings)
    ? report.health.detailedFindings
    : [];
  return findings.some(
    (finding:any) => String(finding.status ?? "").toLowerCase() === "active",
  );
}

function sortActionsDeterministically(
  plan: AIRemediationPlan,
): AIRemediationPlan {
  const riskWeight: Record<
    AIRemediationPlan["actions"][number]["risk"],
    number
  > = {
    low: 1,
    medium: 2,
    high: 3,
    critical: 4,
  };
  const actions = [...plan.actions].sort((a, b) => {
    const approvalDifference =
      Number(a.requiresApproval) - Number(b.requiresApproval);
    if (approvalDifference !== 0) {
      return approvalDifference;
    }
    return riskWeight[a.risk] - riskWeight[b.risk];
  });

  return {
    ...plan,
    actions,
  };
}

function determineFinalState(execution: RemediationExecutionReport): {
  state: AgenticRemediationState;
  resolved: boolean;
  stopped: boolean;
  reason: string;
} {
  if (execution.awaitingApprovalCount > 0) {
    return {
      state: "AWAITING_APPROVAL",
      resolved: false,
      stopped: true,
      reason:
        "Remediation stopped because one or more actions require explicit human approval.",
    };
  }
  if (execution.blockedCount > 0 && execution.executedCount === 0) {
    return {
      state: "POLICY_BLOCKED",
      resolved: false,
      stopped: true,
      reason:
        "Remediation stopped because deterministic policy blocked the available actions.",
    };
  }
  if (execution.verificationFailedCount > 0) {
    return {
      state: "FAILED",
      resolved: false,
      stopped: true,
      reason:
        "Remediation stopped because deterministic post-execution verification failed.",
    };
  }
  if (execution.failedCount > 0) {
    return {
      state: "FAILED",
      resolved: false,
      stopped: true,
      reason: "Remediation stopped because infrastructure execution failed.",
    };
  }
  if (
    execution.executedCount > 0 &&
    execution.verifiedCount === execution.executedCount
  ) {
    return {
      state: "RESOLVED",
      resolved: true,
      stopped: true,
      reason:
        "Remediation completed and every executed action passed deterministic verification.",
    };
  }

  return {
    state: "FAILED",
    resolved: false,
    stopped: true,
    reason:
      "Remediation completed without deterministic evidence that the incident was resolved.",
  };
}

export async function runAgenticRemediationLoop(
  incidentReport: IncidentReport,
  plan: AIRemediationPlan | null,
  options: AgenticRemediationOptions = {},
): Promise<AgenticRemediationResult> {
  const startedAt = new Date().toISOString();

  const mode = options.mode ?? "observe";
  const maxActions = Math.max(1, Math.min(options.maxActions ?? 2, 3));

  const steps: AgenticRemediationStep[] = [];

  const pushStep = (
    state: AgenticRemediationState,
    message: string,
    actionId?: string,
  ) => {
    steps.push({
      state,
      timestamp: new Date().toISOString(),
      message,
      actionId,
    });
  };

  const score = getIncidentScore(incidentReport);
  const level = getIncidentLevel(incidentReport);

  pushStep(
    "DETECTED",
    `Incident detected with deterministic score ${score} and level ${level}.`,
  );

  if (!hasActiveIncident(incidentReport)) {
    pushStep(
      "RESOLVED",
      "No active incident remains in the deterministic incident report.",
    );

    return {
      incidentGeneratedAt: incidentReport.generatedAt,
      state: "RESOLVED",
      resolved: true,
      stopped: true,
      incidentScore: score,
      incidentLevel: level,
      plan: null,
      steps,
      attemptedActions: 0,
      maxActions,
      reason: "No active deterministic incident remains to remediate.",
      startedAt,
      completedAt: new Date().toISOString(),
    };
  }

  pushStep(
    "DIAGNOSED",
    "Deterministic health and incident analysis identified an active incident.",
  );

  if (!plan || !plan.available || plan.actions.length === 0) {
    pushStep(
      "FAILED",
      "No executable remediation plan is available for the active incident.",
    );

    return {
      incidentGeneratedAt: incidentReport.generatedAt,
      state: "FAILED",
      resolved: false,
      stopped: true,
      incidentScore: score,
      incidentLevel: level,
      plan,
      steps,
      attemptedActions: 0,
      maxActions,
      reason:
        "An active incident exists but no executable remediation action is available.",
      startedAt,
      completedAt: new Date().toISOString(),
    };
  }

  const boundedPlan = sortActionsDeterministically({
    ...plan,
    actions: plan.actions.slice(0, maxActions),
  });

  pushStep(
    "PLANNED",
    `Deterministically ordered ${boundedPlan.actions.length} remediation action(s).`,
  );

  if (mode === "observe") {
    pushStep(
      "EXECUTING",
      "Observe mode selected. No infrastructure changes will be made.",
    );
  } else if (mode === "dry-run") {
    pushStep(
      "EXECUTING",
      "Dry-run mode selected. Infrastructure changes will be simulated only.",
    );
  } else {
    pushStep(
      "EXECUTING",
      "Execute mode selected. Every action will be re-evaluated by deterministic policy before execution.",
    );
  }

  const execution = await executeRemediationPlan(boundedPlan, mode, {
    approvalIds: options.approvalIds,
    verify: options.verify !== false,
  });

  if (execution.executedCount > 0) {
    pushStep(
      "VERIFYING",
      `Deterministic verification evaluated ${execution.executedCount} executed action(s).`,
    );
  }

  const finalState = determineFinalState(execution);

  pushStep(finalState.state, finalState.reason);

  return {
    incidentGeneratedAt: incidentReport.generatedAt,
    state: finalState.state,
    resolved: finalState.resolved,
    stopped: finalState.stopped,
    incidentScore: score,
    incidentLevel: level,
    plan: boundedPlan,
    execution,
    steps,
    attemptedActions: boundedPlan.actions.length,
    maxActions,
    reason: finalState.reason,
    startedAt,
    completedAt: new Date().toISOString(),
  };
}
